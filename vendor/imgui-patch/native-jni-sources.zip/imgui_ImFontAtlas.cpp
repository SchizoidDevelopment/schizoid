#include <imgui_ImFontAtlas.h>

//@line:39

        #include "_common.h"

        #define IM_FONT_ATLAS ((ImFontAtlas*)STRUCT_PTR)
        #include "imgui_internal.h"
        #include <climits>
        #include <new>
        #include <cmath>
        bool JavaTrackFontRanges(ImFontAtlas*, ImWchar*) noexcept;
        void JavaUntrackFontRanges(ImFontAtlas*, ImWchar*) noexcept;
        static void fontThrow(JNIEnv* env, const char* type, const char* message) {
            if (env->ExceptionCheck()) return;
            jclass cls = env->FindClass(type);
            if (cls) { env->ThrowNew(cls, message); env->DeleteLocalRef(cls); }
        }

        jmethodID jImFontAtlasCreateAlpha8PixelsMID;
        jmethodID jImFontAtlasCreateRgba32PixelsMID;
     JNIEXPORT void JNICALL Java_imgui_ImFontAtlas_nInit(JNIEnv* env, jclass clazz) {


//@line:59

        jclass jImFontAtlasClass = env->FindClass("imgui/ImFontAtlas");

        jImFontAtlasCreateAlpha8PixelsMID = env->GetMethodID(jImFontAtlasClass, "createAlpha8Pixels", "(I)Ljava/nio/ByteBuffer;");
        jImFontAtlasCreateRgba32PixelsMID = env->GetMethodID(jImFontAtlasClass, "createRgba32Pixels", "(I)Ljava/nio/ByteBuffer;");
    

}

JNIEXPORT jlong JNICALL Java_imgui_ImFontAtlas_nCreate(JNIEnv* env, jobject object) {


//@line:71

        return (intptr_t)(new ImFontAtlas());
    

}

JNIEXPORT jlong JNICALL Java_imgui_ImFontAtlas_nAddFont(JNIEnv* env, jobject object, jlong imFontConfigPtr) {


//@line:79

        return (intptr_t)IM_FONT_ATLAS->AddFont((ImFontConfig*)imFontConfigPtr);
    

}

JNIEXPORT jlong JNICALL Java_imgui_ImFontAtlas_nAddFontDefault__(JNIEnv* env, jobject object) {


//@line:87

        return (intptr_t)IM_FONT_ATLAS->AddFontDefault();
    

}

JNIEXPORT jlong JNICALL Java_imgui_ImFontAtlas_nAddFontDefault__J(JNIEnv* env, jobject object, jlong imFontConfigPtr) {


//@line:95

        return (intptr_t)IM_FONT_ATLAS->AddFontDefault((ImFontConfig*)imFontConfigPtr);
    

}

JNIEXPORT jlong JNICALL Java_imgui_ImFontAtlas_nAddFile(JNIEnv* env, jobject object, jobject filenameObject, jfloat size, jlong configPtr, jobject rangesObject) {


//@line:127

        if (!filenameObject) { fontThrow(env, "java/lang/NullPointerException", "filename"); return 0; }
        ImFontAtlas* atlas = IM_FONT_ATLAS;
        if (env->ExceptionCheck()) return 0;
        if (!atlas) { fontThrow(env, "java/lang/IllegalStateException", "null atlas"); return 0; }
        jstring name = (jstring)filenameObject;
        jshortArray array = (jshortArray)rangesObject;
        ImWchar* copy = NULL;
        if (array) {
            jsize n = env->GetArrayLength(array);
            if (env->ExceptionCheck()) return 0;
            if (n < 3 || !(n & 1) || (size_t)n > SIZE_MAX / sizeof(ImWchar)) {
                fontThrow(env, "java/lang/IllegalArgumentException", "invalid glyph ranges"); return 0;
            }
            jshort* values = env->GetShortArrayElements(array, NULL);
            if (!values) return 0;
            bool valid = values[n-1] == 0;
            for (jsize i = 0; valid && i < n-1; i += 2)
                valid = (unsigned short)values[i] != 0 && (unsigned short)values[i] <= (unsigned short)values[i+1];
            if (valid) {
                copy = (ImWchar*)IM_ALLOC((size_t)n * sizeof(ImWchar));
                if (copy) for (jsize i = 0; i < n; ++i) copy[i] = (ImWchar)(unsigned short)values[i];
            }
            env->ReleaseShortArrayElements(array, values, JNI_ABORT);
            if (!valid) { fontThrow(env, "java/lang/IllegalArgumentException", "invalid glyph ranges"); return 0; }
            if (!copy) { fontThrow(env, "java/lang/OutOfMemoryError", "glyph ranges"); return 0; }
        }
        const char* filename = env->GetStringUTFChars(name, NULL);
        if (!filename) { if (copy) IM_FREE(copy); return 0; }
        if (copy && !JavaTrackFontRanges(atlas, copy)) {
            IM_FREE(copy); env->ReleaseStringUTFChars(name, filename);
            fontThrow(env, "java/lang/OutOfMemoryError", "glyph range tracking"); return 0;
        }
        ImFontConfig cfg = configPtr ? *(ImFontConfig*)configPtr : ImFontConfig();
        if (atlas->Locked || (cfg.MergeMode && atlas->Fonts.empty()) || cfg.FontData != NULL || (!copy && cfg.GlyphRanges != NULL)) {
            if (copy) JavaUntrackFontRanges(atlas, copy);
            env->ReleaseStringUTFChars(name, filename);
            fontThrow(env, "java/lang/IllegalStateException", "invalid atlas or font config"); return 0;
        }
        size_t dataSize = 0;
        void* data = ImFileLoadToMemory(filename, "rb", &dataSize, 0);
        env->ReleaseStringUTFChars(name, filename);
        if (!data || dataSize == 0 || dataSize > INT_MAX) {
            if (data) IM_FREE(data);
            if (copy) JavaUntrackFontRanges(atlas, copy);
            return 0;
        }
        cfg.FontDataOwnedByAtlas = true;
        ImFont* font = NULL;
        try { font = atlas->AddFontFromMemoryTTF(data, (int)dataSize, size, &cfg, copy); }
        catch (const std::bad_alloc&) { fontThrow(env, "java/lang/OutOfMemoryError", "font allocation; atlas state may be invalid"); return 0; }
        catch (...) { fontThrow(env, "java/lang/RuntimeException", "native font error; atlas state may be invalid"); return 0; }
        if (!font) { IM_FREE(data); if (copy) JavaUntrackFontRanges(atlas, copy); }
        return (intptr_t)font;
    

}

static inline jlong wrapped_Java_imgui_ImFontAtlas_nAddFontFromMemoryTTF___3BIF
(JNIEnv* env, jobject object, jbyteArray obj_fontData, jint fontSize, jfloat sizePixels, char* fontData) {

//@line:190

        return (intptr_t)IM_FONT_ATLAS->AddFontFromMemoryTTF(&fontData[0], fontSize, sizePixels);
    
}

JNIEXPORT jlong JNICALL Java_imgui_ImFontAtlas_nAddFontFromMemoryTTF___3BIF(JNIEnv* env, jobject object, jbyteArray obj_fontData, jint fontSize, jfloat sizePixels) {
	char* fontData = (char*)env->GetPrimitiveArrayCritical(obj_fontData, 0);

	jlong JNI_returnValue = wrapped_Java_imgui_ImFontAtlas_nAddFontFromMemoryTTF___3BIF(env, object, obj_fontData, fontSize, sizePixels, fontData);

	env->ReleasePrimitiveArrayCritical(obj_fontData, fontData, 0);

	return JNI_returnValue;
}

static inline jlong wrapped_Java_imgui_ImFontAtlas_nAddFontFromMemoryTTF___3BIFJ
(JNIEnv* env, jobject object, jbyteArray obj_fontData, jint fontSize, jfloat sizePixels, jlong imFontConfigPtr, char* fontData) {

//@line:203

        return (intptr_t)IM_FONT_ATLAS->AddFontFromMemoryTTF(&fontData[0], fontSize, sizePixels, (ImFontConfig*)imFontConfigPtr);
    
}

JNIEXPORT jlong JNICALL Java_imgui_ImFontAtlas_nAddFontFromMemoryTTF___3BIFJ(JNIEnv* env, jobject object, jbyteArray obj_fontData, jint fontSize, jfloat sizePixels, jlong imFontConfigPtr) {
	char* fontData = (char*)env->GetPrimitiveArrayCritical(obj_fontData, 0);

	jlong JNI_returnValue = wrapped_Java_imgui_ImFontAtlas_nAddFontFromMemoryTTF___3BIFJ(env, object, obj_fontData, fontSize, sizePixels, imFontConfigPtr, fontData);

	env->ReleasePrimitiveArrayCritical(obj_fontData, fontData, 0);

	return JNI_returnValue;
}

static inline jlong wrapped_Java_imgui_ImFontAtlas_nAddFontFromMemoryTTF___3BIF_3S
(JNIEnv* env, jobject object, jbyteArray obj_fontData, jint fontSize, jfloat sizePixels, jshortArray obj_glyphRanges, char* fontData, short* glyphRanges) {

//@line:215

        return (intptr_t)IM_FONT_ATLAS->AddFontFromMemoryTTF(&fontData[0], fontSize, sizePixels, NULL, (ImWchar*)&glyphRanges[0]);
    
}

JNIEXPORT jlong JNICALL Java_imgui_ImFontAtlas_nAddFontFromMemoryTTF___3BIF_3S(JNIEnv* env, jobject object, jbyteArray obj_fontData, jint fontSize, jfloat sizePixels, jshortArray obj_glyphRanges) {
	char* fontData = (char*)env->GetPrimitiveArrayCritical(obj_fontData, 0);
	short* glyphRanges = (short*)env->GetPrimitiveArrayCritical(obj_glyphRanges, 0);

	jlong JNI_returnValue = wrapped_Java_imgui_ImFontAtlas_nAddFontFromMemoryTTF___3BIF_3S(env, object, obj_fontData, fontSize, sizePixels, obj_glyphRanges, fontData, glyphRanges);

	env->ReleasePrimitiveArrayCritical(obj_fontData, fontData, 0);
	env->ReleasePrimitiveArrayCritical(obj_glyphRanges, glyphRanges, 0);

	return JNI_returnValue;
}

static inline jlong wrapped_Java_imgui_ImFontAtlas_nAddFontFromMemoryTTF___3BIFJ_3S
(JNIEnv* env, jobject object, jbyteArray obj_fontData, jint fontSize, jfloat sizePixels, jlong imFontConfigPtr, jshortArray obj_glyphRanges, char* fontData, short* glyphRanges) {

//@line:227

        return (intptr_t)IM_FONT_ATLAS->AddFontFromMemoryTTF(&fontData[0], fontSize, sizePixels, (ImFontConfig*)imFontConfigPtr, (ImWchar*)&glyphRanges[0]);
    
}

JNIEXPORT jlong JNICALL Java_imgui_ImFontAtlas_nAddFontFromMemoryTTF___3BIFJ_3S(JNIEnv* env, jobject object, jbyteArray obj_fontData, jint fontSize, jfloat sizePixels, jlong imFontConfigPtr, jshortArray obj_glyphRanges) {
	char* fontData = (char*)env->GetPrimitiveArrayCritical(obj_fontData, 0);
	short* glyphRanges = (short*)env->GetPrimitiveArrayCritical(obj_glyphRanges, 0);

	jlong JNI_returnValue = wrapped_Java_imgui_ImFontAtlas_nAddFontFromMemoryTTF___3BIFJ_3S(env, object, obj_fontData, fontSize, sizePixels, imFontConfigPtr, obj_glyphRanges, fontData, glyphRanges);

	env->ReleasePrimitiveArrayCritical(obj_fontData, fontData, 0);
	env->ReleasePrimitiveArrayCritical(obj_glyphRanges, glyphRanges, 0);

	return JNI_returnValue;
}

static inline jlong wrapped_Java_imgui_ImFontAtlas_nAddFontFromMemoryCompressedTTF___3BIF
(JNIEnv* env, jobject object, jbyteArray obj_compressedFontData, jint fontSize, jfloat sizePixels, char* compressedFontData) {

//@line:238

        return (intptr_t)IM_FONT_ATLAS->AddFontFromMemoryCompressedTTF(&compressedFontData[0], fontSize, sizePixels);
    
}

JNIEXPORT jlong JNICALL Java_imgui_ImFontAtlas_nAddFontFromMemoryCompressedTTF___3BIF(JNIEnv* env, jobject object, jbyteArray obj_compressedFontData, jint fontSize, jfloat sizePixels) {
	char* compressedFontData = (char*)env->GetPrimitiveArrayCritical(obj_compressedFontData, 0);

	jlong JNI_returnValue = wrapped_Java_imgui_ImFontAtlas_nAddFontFromMemoryCompressedTTF___3BIF(env, object, obj_compressedFontData, fontSize, sizePixels, compressedFontData);

	env->ReleasePrimitiveArrayCritical(obj_compressedFontData, compressedFontData, 0);

	return JNI_returnValue;
}

static inline jlong wrapped_Java_imgui_ImFontAtlas_nAddFontFromMemoryCompressedTTF___3BIFJ
(JNIEnv* env, jobject object, jbyteArray obj_compressedFontData, jint fontSize, jfloat sizePixels, jlong imFontConfigPtr, char* compressedFontData) {

//@line:249

        return (intptr_t)IM_FONT_ATLAS->AddFontFromMemoryCompressedTTF(&compressedFontData[0], fontSize, sizePixels, (ImFontConfig*)imFontConfigPtr);
    
}

JNIEXPORT jlong JNICALL Java_imgui_ImFontAtlas_nAddFontFromMemoryCompressedTTF___3BIFJ(JNIEnv* env, jobject object, jbyteArray obj_compressedFontData, jint fontSize, jfloat sizePixels, jlong imFontConfigPtr) {
	char* compressedFontData = (char*)env->GetPrimitiveArrayCritical(obj_compressedFontData, 0);

	jlong JNI_returnValue = wrapped_Java_imgui_ImFontAtlas_nAddFontFromMemoryCompressedTTF___3BIFJ(env, object, obj_compressedFontData, fontSize, sizePixels, imFontConfigPtr, compressedFontData);

	env->ReleasePrimitiveArrayCritical(obj_compressedFontData, compressedFontData, 0);

	return JNI_returnValue;
}

static inline jlong wrapped_Java_imgui_ImFontAtlas_nAddFontFromMemoryCompressedTTF___3BIF_3S
(JNIEnv* env, jobject object, jbyteArray obj_compressedFontData, jint fontSize, jfloat sizePixels, jshortArray obj_glyphRanges, char* compressedFontData, short* glyphRanges) {

//@line:260

        return (intptr_t)IM_FONT_ATLAS->AddFontFromMemoryCompressedTTF(&compressedFontData[0], fontSize, sizePixels, NULL, (ImWchar*)&glyphRanges[0]);
    
}

JNIEXPORT jlong JNICALL Java_imgui_ImFontAtlas_nAddFontFromMemoryCompressedTTF___3BIF_3S(JNIEnv* env, jobject object, jbyteArray obj_compressedFontData, jint fontSize, jfloat sizePixels, jshortArray obj_glyphRanges) {
	char* compressedFontData = (char*)env->GetPrimitiveArrayCritical(obj_compressedFontData, 0);
	short* glyphRanges = (short*)env->GetPrimitiveArrayCritical(obj_glyphRanges, 0);

	jlong JNI_returnValue = wrapped_Java_imgui_ImFontAtlas_nAddFontFromMemoryCompressedTTF___3BIF_3S(env, object, obj_compressedFontData, fontSize, sizePixels, obj_glyphRanges, compressedFontData, glyphRanges);

	env->ReleasePrimitiveArrayCritical(obj_compressedFontData, compressedFontData, 0);
	env->ReleasePrimitiveArrayCritical(obj_glyphRanges, glyphRanges, 0);

	return JNI_returnValue;
}

static inline jlong wrapped_Java_imgui_ImFontAtlas_nAddFontFromMemoryCompressedTTF___3BIFJ_3S
(JNIEnv* env, jobject object, jbyteArray obj_compressedFontData, jint fontSize, jfloat sizePixels, jlong imFontConfigPtr, jshortArray obj_glyphRanges, char* compressedFontData, short* glyphRanges) {

//@line:271

        return (intptr_t)IM_FONT_ATLAS->AddFontFromMemoryCompressedTTF(&compressedFontData[0], fontSize, sizePixels, (ImFontConfig*)imFontConfigPtr, (ImWchar*)&glyphRanges[0]);
    
}

JNIEXPORT jlong JNICALL Java_imgui_ImFontAtlas_nAddFontFromMemoryCompressedTTF___3BIFJ_3S(JNIEnv* env, jobject object, jbyteArray obj_compressedFontData, jint fontSize, jfloat sizePixels, jlong imFontConfigPtr, jshortArray obj_glyphRanges) {
	char* compressedFontData = (char*)env->GetPrimitiveArrayCritical(obj_compressedFontData, 0);
	short* glyphRanges = (short*)env->GetPrimitiveArrayCritical(obj_glyphRanges, 0);

	jlong JNI_returnValue = wrapped_Java_imgui_ImFontAtlas_nAddFontFromMemoryCompressedTTF___3BIFJ_3S(env, object, obj_compressedFontData, fontSize, sizePixels, imFontConfigPtr, obj_glyphRanges, compressedFontData, glyphRanges);

	env->ReleasePrimitiveArrayCritical(obj_compressedFontData, compressedFontData, 0);
	env->ReleasePrimitiveArrayCritical(obj_glyphRanges, glyphRanges, 0);

	return JNI_returnValue;
}

static inline jlong wrapped_Java_imgui_ImFontAtlas_nAddFontFromMemoryCompressedBase85TTF__Ljava_lang_String_2F
(JNIEnv* env, jobject object, jstring obj_compressedFontDataBase85, jfloat sizePixels, char* compressedFontDataBase85) {

//@line:282

        return (intptr_t)IM_FONT_ATLAS->AddFontFromMemoryCompressedBase85TTF(compressedFontDataBase85, sizePixels);
    
}

JNIEXPORT jlong JNICALL Java_imgui_ImFontAtlas_nAddFontFromMemoryCompressedBase85TTF__Ljava_lang_String_2F(JNIEnv* env, jobject object, jstring obj_compressedFontDataBase85, jfloat sizePixels) {
	char* compressedFontDataBase85 = (char*)env->GetStringUTFChars(obj_compressedFontDataBase85, 0);

	jlong JNI_returnValue = wrapped_Java_imgui_ImFontAtlas_nAddFontFromMemoryCompressedBase85TTF__Ljava_lang_String_2F(env, object, obj_compressedFontDataBase85, sizePixels, compressedFontDataBase85);

	env->ReleaseStringUTFChars(obj_compressedFontDataBase85, compressedFontDataBase85);

	return JNI_returnValue;
}

static inline jlong wrapped_Java_imgui_ImFontAtlas_nAddFontFromMemoryCompressedBase85TTF__Ljava_lang_String_2FJ
(JNIEnv* env, jobject object, jstring obj_compressedFontDataBase85, jfloat sizePixels, jlong imFontConfigPtr, char* compressedFontDataBase85) {

//@line:293

        return (intptr_t)IM_FONT_ATLAS->AddFontFromMemoryCompressedBase85TTF(compressedFontDataBase85, sizePixels, (ImFontConfig*)imFontConfigPtr);
    
}

JNIEXPORT jlong JNICALL Java_imgui_ImFontAtlas_nAddFontFromMemoryCompressedBase85TTF__Ljava_lang_String_2FJ(JNIEnv* env, jobject object, jstring obj_compressedFontDataBase85, jfloat sizePixels, jlong imFontConfigPtr) {
	char* compressedFontDataBase85 = (char*)env->GetStringUTFChars(obj_compressedFontDataBase85, 0);

	jlong JNI_returnValue = wrapped_Java_imgui_ImFontAtlas_nAddFontFromMemoryCompressedBase85TTF__Ljava_lang_String_2FJ(env, object, obj_compressedFontDataBase85, sizePixels, imFontConfigPtr, compressedFontDataBase85);

	env->ReleaseStringUTFChars(obj_compressedFontDataBase85, compressedFontDataBase85);

	return JNI_returnValue;
}

static inline jlong wrapped_Java_imgui_ImFontAtlas_nAddFontFromMemoryCompressedBase85TTF__Ljava_lang_String_2F_3S
(JNIEnv* env, jobject object, jstring obj_compressedFontDataBase85, jfloat sizePixels, jshortArray obj_glyphRanges, char* compressedFontDataBase85, short* glyphRanges) {

//@line:304

        return (intptr_t)IM_FONT_ATLAS->AddFontFromMemoryCompressedBase85TTF(compressedFontDataBase85, sizePixels, NULL, (ImWchar*)&glyphRanges[0]);
    
}

JNIEXPORT jlong JNICALL Java_imgui_ImFontAtlas_nAddFontFromMemoryCompressedBase85TTF__Ljava_lang_String_2F_3S(JNIEnv* env, jobject object, jstring obj_compressedFontDataBase85, jfloat sizePixels, jshortArray obj_glyphRanges) {
	char* compressedFontDataBase85 = (char*)env->GetStringUTFChars(obj_compressedFontDataBase85, 0);
	short* glyphRanges = (short*)env->GetPrimitiveArrayCritical(obj_glyphRanges, 0);

	jlong JNI_returnValue = wrapped_Java_imgui_ImFontAtlas_nAddFontFromMemoryCompressedBase85TTF__Ljava_lang_String_2F_3S(env, object, obj_compressedFontDataBase85, sizePixels, obj_glyphRanges, compressedFontDataBase85, glyphRanges);

	env->ReleasePrimitiveArrayCritical(obj_glyphRanges, glyphRanges, 0);
	env->ReleaseStringUTFChars(obj_compressedFontDataBase85, compressedFontDataBase85);

	return JNI_returnValue;
}

static inline jlong wrapped_Java_imgui_ImFontAtlas_nAddFontFromMemoryCompressedBase85TTF__Ljava_lang_String_2FJ_3S
(JNIEnv* env, jobject object, jstring obj_compressedFontDataBase85, jfloat sizePixels, jlong imFontConfigPtr, jshortArray obj_glyphRanges, char* compressedFontDataBase85, short* glyphRanges) {

//@line:315

        return (intptr_t)IM_FONT_ATLAS->AddFontFromMemoryCompressedBase85TTF(compressedFontDataBase85, sizePixels, (ImFontConfig*)imFontConfigPtr, (ImWchar*)&glyphRanges[0]);
    
}

JNIEXPORT jlong JNICALL Java_imgui_ImFontAtlas_nAddFontFromMemoryCompressedBase85TTF__Ljava_lang_String_2FJ_3S(JNIEnv* env, jobject object, jstring obj_compressedFontDataBase85, jfloat sizePixels, jlong imFontConfigPtr, jshortArray obj_glyphRanges) {
	char* compressedFontDataBase85 = (char*)env->GetStringUTFChars(obj_compressedFontDataBase85, 0);
	short* glyphRanges = (short*)env->GetPrimitiveArrayCritical(obj_glyphRanges, 0);

	jlong JNI_returnValue = wrapped_Java_imgui_ImFontAtlas_nAddFontFromMemoryCompressedBase85TTF__Ljava_lang_String_2FJ_3S(env, object, obj_compressedFontDataBase85, sizePixels, imFontConfigPtr, obj_glyphRanges, compressedFontDataBase85, glyphRanges);

	env->ReleasePrimitiveArrayCritical(obj_glyphRanges, glyphRanges, 0);
	env->ReleaseStringUTFChars(obj_compressedFontDataBase85, compressedFontDataBase85);

	return JNI_returnValue;
}

JNIEXPORT void JNICALL Java_imgui_ImFontAtlas_clearInputData(JNIEnv* env, jobject object) {


//@line:322

        IM_FONT_ATLAS->ClearInputData();
    

}

JNIEXPORT void JNICALL Java_imgui_ImFontAtlas_clearTexData(JNIEnv* env, jobject object) {


//@line:329

        IM_FONT_ATLAS->ClearTexData();
    

}

JNIEXPORT void JNICALL Java_imgui_ImFontAtlas_clearFonts(JNIEnv* env, jobject object) {


//@line:336

        IM_FONT_ATLAS->ClearFonts();
    

}

JNIEXPORT void JNICALL Java_imgui_ImFontAtlas_clear(JNIEnv* env, jobject object) {


//@line:343

        IM_FONT_ATLAS->Clear();
    

}

JNIEXPORT jboolean JNICALL Java_imgui_ImFontAtlas_build(JNIEnv* env, jobject object) {


//@line:356

        return IM_FONT_ATLAS->Build();
    

}

JNIEXPORT void JNICALL Java_imgui_ImFontAtlas_getTexDataAsAlpha8(JNIEnv* env, jobject object, jintArray obj_outWidth, jintArray obj_outHeight, jintArray obj_outBytesPerPixel) {
	int* outWidth = (int*)env->GetPrimitiveArrayCritical(obj_outWidth, 0);
	int* outHeight = (int*)env->GetPrimitiveArrayCritical(obj_outHeight, 0);
	int* outBytesPerPixel = (int*)env->GetPrimitiveArrayCritical(obj_outBytesPerPixel, 0);


//@line:385

        unsigned char* pixels;
        IM_FONT_ATLAS->GetTexDataAsAlpha8(&pixels, &outWidth[0], &outHeight[0], &outBytesPerPixel[0]);

        int size = outWidth[0] * outHeight[0] * outBytesPerPixel[0];

        jobject jBuffer = env->CallObjectMethod(object, jImFontAtlasCreateAlpha8PixelsMID, size);
        char* buffer = (char*)env->GetDirectBufferAddress(jBuffer);

        memcpy(buffer, pixels, size);
    
	env->ReleasePrimitiveArrayCritical(obj_outWidth, outWidth, 0);
	env->ReleasePrimitiveArrayCritical(obj_outHeight, outHeight, 0);
	env->ReleasePrimitiveArrayCritical(obj_outBytesPerPixel, outBytesPerPixel, 0);

}

JNIEXPORT void JNICALL Java_imgui_ImFontAtlas_nGetTexDataAsRGBA32(JNIEnv* env, jobject object, jintArray obj_outWidth, jintArray obj_outHeight, jintArray obj_outBytesPerPixel) {
	int* outWidth = (int*)env->GetPrimitiveArrayCritical(obj_outWidth, 0);
	int* outHeight = (int*)env->GetPrimitiveArrayCritical(obj_outHeight, 0);
	int* outBytesPerPixel = (int*)env->GetPrimitiveArrayCritical(obj_outBytesPerPixel, 0);


//@line:422

        unsigned char* pixels;
        IM_FONT_ATLAS->GetTexDataAsRGBA32(&pixels, &outWidth[0], &outHeight[0], &outBytesPerPixel[0]);

        int size = outWidth[0] * outHeight[0] * outBytesPerPixel[0];

        jobject jBuffer = env->CallObjectMethod(object, jImFontAtlasCreateRgba32PixelsMID, size);
        char* buffer = (char*)env->GetDirectBufferAddress(jBuffer);

        memcpy(buffer, pixels, size);
    
	env->ReleasePrimitiveArrayCritical(obj_outWidth, outWidth, 0);
	env->ReleasePrimitiveArrayCritical(obj_outHeight, outHeight, 0);
	env->ReleasePrimitiveArrayCritical(obj_outBytesPerPixel, outBytesPerPixel, 0);

}

JNIEXPORT jboolean JNICALL Java_imgui_ImFontAtlas_isBuilt(JNIEnv* env, jobject object) {


//@line:434

        return IM_FONT_ATLAS->IsBuilt();
    

}

JNIEXPORT void JNICALL Java_imgui_ImFontAtlas_setTexID(JNIEnv* env, jobject object, jint textureID) {


//@line:438

        IM_FONT_ATLAS->SetTexID((ImTextureID)(intptr_t)textureID);
    

}


//@line:450

        #define RETURN_GLYPH_2_SHORT(glyphs) \
            const ImWchar* ranges = glyphs; \
            int size = 0; \
            for (; ranges[0]; ranges += 2) \
                size += 2; \
            jshortArray jShorts = env->NewShortArray(size + 1); \
            if (!jShorts) return NULL; \
            env->SetShortArrayRegion(jShorts, 0, size, (jshort*)glyphs); \
            return jShorts;
     JNIEXPORT jshortArray JNICALL Java_imgui_ImFontAtlas_getGlyphRangesDefault(JNIEnv* env, jobject object) {


//@line:465

        RETURN_GLYPH_2_SHORT(IM_FONT_ATLAS->GetGlyphRangesDefault());
    

}

JNIEXPORT jshortArray JNICALL Java_imgui_ImFontAtlas_getGlyphRangesKorean(JNIEnv* env, jobject object) {


//@line:472

        RETURN_GLYPH_2_SHORT(IM_FONT_ATLAS->GetGlyphRangesKorean());
    

}

JNIEXPORT jshortArray JNICALL Java_imgui_ImFontAtlas_getGlyphRangesJapanese(JNIEnv* env, jobject object) {


//@line:479

        RETURN_GLYPH_2_SHORT(IM_FONT_ATLAS->GetGlyphRangesJapanese());
    

}

JNIEXPORT jshortArray JNICALL Java_imgui_ImFontAtlas_getGlyphRangesChineseFull(JNIEnv* env, jobject object) {


//@line:486

        RETURN_GLYPH_2_SHORT(IM_FONT_ATLAS->GetGlyphRangesChineseFull());
    

}

JNIEXPORT jshortArray JNICALL Java_imgui_ImFontAtlas_getGlyphRangesChineseSimplifiedCommon(JNIEnv* env, jobject object) {


//@line:493

        RETURN_GLYPH_2_SHORT(IM_FONT_ATLAS->GetGlyphRangesChineseSimplifiedCommon());
    

}

JNIEXPORT jshortArray JNICALL Java_imgui_ImFontAtlas_getGlyphRangesCyrillic(JNIEnv* env, jobject object) {


//@line:500

        RETURN_GLYPH_2_SHORT(IM_FONT_ATLAS->GetGlyphRangesCyrillic());
    

}

JNIEXPORT jshortArray JNICALL Java_imgui_ImFontAtlas_getGlyphRangesThai(JNIEnv* env, jobject object) {


//@line:507

        RETURN_GLYPH_2_SHORT(IM_FONT_ATLAS->GetGlyphRangesThai());
    

}

JNIEXPORT jshortArray JNICALL Java_imgui_ImFontAtlas_getGlyphRangesVietnamese(JNIEnv* env, jobject object) {


//@line:514

        RETURN_GLYPH_2_SHORT(IM_FONT_ATLAS->GetGlyphRangesVietnamese());
    

}

JNIEXPORT jint JNICALL Java_imgui_ImFontAtlas_addCustomRectRegular(JNIEnv* env, jobject object, jint width, jint height) {


//@line:529

        return IM_FONT_ATLAS->AddCustomRectRegular(width, height);
    

}

JNIEXPORT jint JNICALL Java_imgui_ImFontAtlas_nAddCustomRectFontGlyph__JSIIF(JNIEnv* env, jobject object, jlong imFontPtr, jshort id, jint width, jint height, jfloat advanceX) {


//@line:537

        return IM_FONT_ATLAS->AddCustomRectFontGlyph((ImFont*)imFontPtr, id, width, height, advanceX);
    

}

JNIEXPORT jint JNICALL Java_imgui_ImFontAtlas_nAddCustomRectFontGlyph__JSIIFFF(JNIEnv* env, jobject object, jlong imFontPtr, jshort id, jint width, jint height, jfloat advanceX, jfloat offsetX, jfloat offsetY) {


//@line:548

        return IM_FONT_ATLAS->AddCustomRectFontGlyph((ImFont*)imFontPtr, id, width, height, advanceX, ImVec2(offsetX, offsetY));
    

}

JNIEXPORT jboolean JNICALL Java_imgui_ImFontAtlas_getLocked(JNIEnv* env, jobject object) {


//@line:561

        return IM_FONT_ATLAS->Locked;
    

}

JNIEXPORT void JNICALL Java_imgui_ImFontAtlas_setLocked(JNIEnv* env, jobject object, jboolean locked) {


//@line:568

        IM_FONT_ATLAS->Locked = locked;
    

}

JNIEXPORT jint JNICALL Java_imgui_ImFontAtlas_getFlags(JNIEnv* env, jobject object) {


//@line:575

        return IM_FONT_ATLAS->Flags;
    

}

JNIEXPORT void JNICALL Java_imgui_ImFontAtlas_setFlags(JNIEnv* env, jobject object, jint imFontAtlasFlags) {


//@line:582

        IM_FONT_ATLAS->Flags = imFontAtlasFlags;
    

}

JNIEXPORT jint JNICALL Java_imgui_ImFontAtlas_getTexID(JNIEnv* env, jobject object) {


//@line:611

        return (int)(intptr_t)(void*)IM_FONT_ATLAS->TexID;
    

}

JNIEXPORT jint JNICALL Java_imgui_ImFontAtlas_getTexDesiredWidth(JNIEnv* env, jobject object) {


//@line:619

        return IM_FONT_ATLAS->TexDesiredWidth;
    

}

JNIEXPORT void JNICALL Java_imgui_ImFontAtlas_setTexDesiredWidth(JNIEnv* env, jobject object, jint texDesiredWidth) {


//@line:627

        IM_FONT_ATLAS->TexDesiredWidth = texDesiredWidth;
    

}

JNIEXPORT jint JNICALL Java_imgui_ImFontAtlas_getTexGlyphPadding(JNIEnv* env, jobject object) {


//@line:635

        return IM_FONT_ATLAS->TexGlyphPadding;
    

}

JNIEXPORT void JNICALL Java_imgui_ImFontAtlas_setTexGlyphPadding(JNIEnv* env, jobject object, jint texGlyphPadding) {


//@line:643

        IM_FONT_ATLAS->TexGlyphPadding = texGlyphPadding;
    

}

